package cinemaHamid.controller;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import cinemaHamid.model.*;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.NodeOrientation;
import javafx.scene.control.*;
import javafx.scene.layout.Region;
import javafx.util.StringConverter;

public class Controller implements Initializable {
    @FXML
    private ResourceBundle resources;
    @FXML
    private URL location;


    //bilit
    @FXML
    private TableView<Bilit> bilitTable = new TableView<>();
    @FXML
    private TableColumn<Bilit, String> bilitTableCPersonName = new TableColumn<>();
    @FXML
    private TableColumn<Bilit, String> bilitTableCBilitId = new TableColumn<>();
    @FXML
    private TableColumn<Bilit, String> bilitTableCTime = new TableColumn<>();
    @FXML
    private TableColumn<Bilit, String> bilitTableCDate = new TableColumn<>();
    @FXML
    private TableColumn<Bilit, String> bilitTableCSalonName = new TableColumn<>();
    @FXML
    private TableColumn<Bilit, String> bilitTableCFilmName = new TableColumn<>();
    @FXML
    private TableColumn<Bilit, Integer> bilitTableCNumberOfChair = new TableColumn<>();
    @FXML
    private TableColumn<Bilit, Integer> bilitTableCPrice = new TableColumn<>();

    @FXML
    private TextField bilitAddNumberOfChair;
    @FXML
    private Button bilitAddFilmButton;


    @FXML
    private Button bilitDeleteByIdButton;
    @FXML
    private TextField bilitDeleteById;


    @FXML
    private ComboBox<String> bilitAddFilmNameComboList;
    @FXML
    private ComboBox<String> bilitAddSalonNameComboList;
    @FXML
    private Button bilitAddFillSalonComboList;
    //@FXML
    //private ComboBox<String> bilitAddTimeComboList;
    @FXML
    private DatePicker bilitAddFilmDatePicker;
    @FXML
    private TextField bilitAddName;

    //sanss
    @FXML
    private TableView<Sanss> sanssTable = new TableView<>();
    @FXML
    private TableColumn<Sanss, String> sanssTableCFilmName = new TableColumn<>();
    @FXML
    private TableColumn<Sanss, String> sanssTableCSalonName = new TableColumn<>();
    @FXML
    private TableColumn<Sanss, String> sanssTableCTime = new TableColumn<>();
    @FXML
    private TableColumn<Sanss, String> sanssTableCDate = new TableColumn<>();
    @FXML
    private TableColumn<Sanss, Integer> sanssTableCZarfiat = new TableColumn<>();
    @FXML
    private TableColumn<Sanss, String> sanssTableCSanssId = new TableColumn<>();

    @FXML
    private Button sanssAddButton;

    @FXML
    private Button sanssDeleteByIdButton;
    @FXML
    private TextField sanssDeleteById;
    @FXML
    private ComboBox<String> sanssAddFilmNameComboList;
    @FXML
    private ComboBox<String> sanssAddSalonNameComboList;
    @FXML
    private ComboBox<String> sanssAddTimeComboList;
    @FXML
    private DatePicker sanssAddDatePicker = new DatePicker();


    //film
    @FXML
    private TableView<Film> filmTable = new TableView<>();
    @FXML
    private TableColumn<Film, String> filmTableCFilmName = new TableColumn<>();
    @FXML
    private TableColumn<Film, String> filmTableCFilmId = new TableColumn<>();

    @FXML
    private Button filmAddNameButton;
    @FXML
    private TextField filmAddName;
    // @FXML
    //private Button filmUpdateTableButton;
    @FXML
    private Button filmDeleteByIdButton;
    @FXML
    private TextField filmDeleteById;


    //salon
    @FXML
    private TableView<Salon> salonTable = new TableView<>();
    @FXML
    private TableColumn<Salon, String> salonTableCSalonName = new TableColumn<>();
    @FXML
    private TableColumn<Salon, Integer> salonTableCPricePerChair = new TableColumn<>();
    @FXML
    private TableColumn<Salon, Integer> salonTableCZarfiat = new TableColumn<>();

    @FXML
    private TextField salonAddName;
    @FXML
    private TextField salonAddPrice;
    @FXML
    private TextField salonAddZarfiat;
    @FXML
    private Button salonAddButton;
    /*
    @FXML
    private TextField salonModifyPrice;
    @FXML
    private TextField salonModifyZarfiat;
    @FXML
    private Button salonModifyButton;
    @FXML
    private Button salonUpdateTableButton;
    @FXML
    private CheckBox salonModifyPriceConstCheck;
    @FXML
    private CheckBox salonModifyZarfiatConstCheck;
    @FXML
    private Button salonDeleteButton;
    @FXML
    private TextField salonDeleteName;
    @FXML
    private TextField salonModifyName;
*/
    @FXML
    private Button salonDeleteButton;
    @FXML
    private TextField salonDeleteName;

    //report
    @FXML
    private ComboBox<String> reportNameOfFilmThatHaveSanss;
    @FXML
    private Button reportGetAllSellOfAFilmButton;
    @FXML
    private Label reportGetAllSellOfAFilmLable;
    @FXML
    private ComboBox<String> reportNameOfSalonThatHaveSanss;
    @FXML
    private Button reportGetAllSellOfASalonButton;
    @FXML
    private Label reportGetAllSellOfASalonLable;


    @FXML
    private Button reportGetMostSellFilmButton;
    @FXML
    private Label reportGetMostSellFilmLable;
    @FXML
    private Button reportGetMostSellSalonButton;
    @FXML
    private Label reportGetMostSellSalonLable;
    //@FXML
    //private Button reportGetMostSellTimeButton;
    //@FXML
    //private Label reportGetMostSellTimeLable;
    @FXML
    private ComboBox<String> reportNameOfFilmThatHaveSanssOnDate;
    @FXML
    private Button reportGetAllSellOfAFilmButtonOnDate;
    @FXML
    private Label reportGetAllSellOfAFilmLableOnDate;
    @FXML
    private ComboBox<String> reportNameOfSalonThatHaveSanssOnDate;
    @FXML
    private Button reportGetAllSellOfAFSalonButtonOnDate;
    @FXML
    private Label reportGetAllSellOfASalonLableOnDate;
    //@FXML
    //private Button reportGetMostSellFilmButtonOnDate;
    //@FXML
    ///private Label reportGetMostSellFilmLableOnDate;
    //@FXML
    //private Label reportGetMostSellSalonLableOnDate;
    //@FXML
    //private Button reportGetMostSellTimeButtonOnDate;
    //@FXML
    //private Label reportGetMostSellTimeLableOnDate;
    @FXML
    private DatePicker reportOnThisDate;


    //playlist
    /*
    @FXML
    private TableView<?> playlistTable;
    @FXML
    private TableColumn<?, ?> playlistTableCDate;
    @FXML
    private TableColumn<?, ?> playlistTableCDateSanss1;
    @FXML
    private TableColumn<?, ?> playlistTableCDateSanss2;
    @FXML
    private TableColumn<?, ?> playlistTableCDateSanss3;
    @FXML
    private TableColumn<?, ?> playlistTableCDateSanss4;

    @FXML
*/
    @FXML
    private DatePicker playlistInThisDate;
    @FXML
    private Button playListButton;
    @FXML
    private Label sanss1;
    @FXML
    private Label sanss2;
    @FXML
    private Label sanss3;
    @FXML
    private Label sanss4;

    ObservableList<Salon> salonList;
    ObservableList<Film> filmList;
    ObservableList<String> sanssFilmName;
    ObservableList<String> sanssSalonName;
    ObservableList<String> bilitSanssSalonName;

    ObservableList<String> bilitFilmName;
    ObservableList<String> sanssTime;
    ObservableList<Sanss> sanssList;
    ObservableList<Bilit> bilitList;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.printf("hi from controller");
        fillTables();
        dateFormatConverter();

        //buttons_salon
        salonAddButton.setOnAction(event -> {
            String sql = "INSERT INTO salon(salon_name,salon_price,salon_zarfiat) VALUES(?,?,?)";
            try {
                Connection connection = dbHandler.getConnection();
                PreparedStatement pstmt = connection.prepareStatement(sql);
                pstmt.setString(1, salonAddName.getText());
                pstmt.setInt(2, Integer.parseInt(salonAddPrice.getText()));
                pstmt.setInt(3, Integer.parseInt(salonAddZarfiat.getText()));
                pstmt.executeUpdate();
            } catch (SQLException throwable) {
                throwable.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            salonList.add(new Salon(salonAddName.getText(), Integer.parseInt(salonAddPrice.getText()), Integer.parseInt(salonAddZarfiat.getText())));
            //initialize(location,resources);
            sanssSalonName.add(salonAddName.getText());

            salonAddName.setText("");
            salonAddPrice.setText("");
            salonAddZarfiat.setText("");
        });

        filmAddNameButton.setOnAction(event -> {
            String temp = null;
            String sql = "INSERT INTO films(film_name,pub_film_id) VALUES(?,?)";
            try {
                Connection connection = dbHandler.getConnection();
                PreparedStatement pstmt = connection.prepareStatement(sql);
                pstmt.setString(1, filmAddName.getText());
                temp = filmAddName.getText().charAt(0) + String.valueOf(Film.countForMe());
                pstmt.setString(2, temp);
                pstmt.executeUpdate();
            } catch (SQLException throwable) {
                throwable.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            filmList.add(new Film(filmAddName.getText(), temp));

            sanssFilmName.add(filmAddName.getText());
            //initialize(location,resources);
            filmAddName.setText("");
        });

        sanssAddButton.setOnAction(event -> {
            String check = checkExistance(sanssAddSalonNameComboList.getValue(), sanssAddTimeComboList.getValue(), String.valueOf(sanssAddDatePicker.getValue()));
            if (check == "") {

                String temp_id = null;
                int zarfiat = 0;
                String sql = "INSERT INTO sanss(film_name,salon_name,sanss_time,sanss_date,zarfiat_mojod,sanss_uniqe_id) VALUES(?,?,?,?,?,?)";
                try {
                    Connection connection = dbHandler.getConnection();
                    PreparedStatement pstmt = connection.prepareStatement(sql);
                    pstmt.setString(1, sanssAddFilmNameComboList.getValue());
                    pstmt.setString(2, sanssAddSalonNameComboList.getValue());
                    pstmt.setString(3, sanssAddTimeComboList.getValue());
                    pstmt.setString(4, String.valueOf(sanssAddDatePicker.getValue()));
                    zarfiat = findZarfiat(sanssAddSalonNameComboList.getValue());
                    pstmt.setInt(5, zarfiat);
                    temp_id = sanssAddSalonNameComboList.getValue() + getFilmId(sanssAddFilmNameComboList.getValue()) + "ت" + String.valueOf(sanssAddDatePicker.getValue()).charAt(8) + String.valueOf(sanssAddDatePicker.getValue()).charAt(9) + "ز" + sanssAddTimeComboList.getValue();
                    pstmt.setString(6, temp_id);
                    pstmt.executeUpdate();
                } catch (SQLException throwable) {
                    throwable.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
                sanssList.add(new Sanss(sanssAddSalonNameComboList.getValue(), sanssAddFilmNameComboList.getValue(), sanssAddTimeComboList.getValue(), String.valueOf(sanssAddDatePicker.getValue()), temp_id, zarfiat));
                //initialize(location,resources);

                bilitFilmName.add(sanssAddFilmNameComboList.getValue());
/////////////////////

                System.out.println("hi if");
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("پیام");
                alert.setHeaderText("اطلاعات سانس");
                String temp = "سانس اضافه شد";
                temp += "\n" + "فیلم:" + sanssAddFilmNameComboList.getValue();
                temp += "\n" + "سالن:" + sanssAddSalonNameComboList.getValue();
                temp += "\n" + "تاریخ:" + String.valueOf(sanssAddDatePicker.getValue());
                temp += "\n" + "زمان:" + sanssAddTimeComboList.getValue();
                temp += "\n" + "ظرفیت:" + zarfiat;
                temp += "\n" + "شناسه سانس:" + temp_id;
                temp += "\n\n" + "!!اگر سانس تکراری وارد کرده باشید در اجرای بعدی برنامه از جدول نمایش حذف خواهد شد";
                alert.setContentText(temp);
                alert.getDialogPane().getScene().setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.showAndWait();


            }else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("پیام");
                alert.setHeaderText("این سانس پر میباشد");
                alert.getDialogPane().getScene().setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.showAndWait();
            }
            sanssAddFilmNameComboList.setValue(null);
            sanssAddSalonNameComboList.setValue(null);
            sanssAddTimeComboList.setValue(null);
            sanssAddDatePicker.setValue(null);
        });

        bilitAddFillSalonComboList.setOnAction(event -> {
            String Date = String.valueOf(bilitAddFilmDatePicker.getValue());
            String film = bilitAddFilmNameComboList.getValue();
            //String time = bilitAddTimeComboList.getValue();

            Connection conn = null;
            try {
                bilitSanssSalonName = FXCollections.observableArrayList();
                String consulta = "select salon_name,sanss_time from sanss  WHERE sanss_date ='" + Date + "' AND film_name='" + film + "'";
                conn = dbHandler.getConnection();
                PreparedStatement ps = conn.prepareStatement(consulta);
                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    bilitSanssSalonName.add("سالن: " + rs.getString("salon_name") + ",زمان: " + rs.getString("sanss_time"));
                }

                bilitAddSalonNameComboList.setItems(bilitSanssSalonName);
                String temp;
                if (bilitSanssSalonName.isEmpty()) {
                    temp = "سانسی برای فیلم مورد نظر شما در تاریخ انتخابی تعریف نشده است";
                } else {
                    temp = "سانس ها یافت شده به بخش لیست سانس ها اضافه شد";
                }
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("پیام");
                alert.setHeaderText(temp);
                alert.getDialogPane().getScene().setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.showAndWait();
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        bilitAddFilmButton.setOnAction(event -> {
            String Sanss_time = null;
            String Sanss_salon_name = null;
            Sanss_time = bilitAddSalonNameComboList.getValue().substring(15);
            Sanss_salon_name = bilitAddSalonNameComboList.getValue().substring(6, 8);
            boolean check = haveChair(bilitAddFilmNameComboList.getValue(), Sanss_time, String.valueOf(bilitAddFilmDatePicker.getValue()), Sanss_salon_name, Integer.parseInt(bilitAddNumberOfChair.getText()));
            if (check) {


                String temp_id = null;
                int zarfiat = 0;
                int price = 0;
                String id = null;
                String sql = "INSERT INTO bilit(name,bilit_id,time,date,salon_name,film_name,number_of_ticket,price) VALUES(?,?,?,?,?,?,?,?)";
                try {
                    Connection connection = dbHandler.getConnection();
                    PreparedStatement pstmt = connection.prepareStatement(sql);

                    pstmt.setString(1, bilitAddName.getText());

                    id = getSanssId(bilitAddFilmNameComboList.getValue(), Sanss_time, String.valueOf(bilitAddFilmDatePicker.getValue()), Sanss_salon_name) + bilitAddName.getText().charAt(0) + bilitAddNumberOfChair.getText();

                    pstmt.setString(2, id);

                    pstmt.setString(3, Sanss_time);
                    pstmt.setString(4, String.valueOf(bilitAddFilmDatePicker.getValue()));
                    pstmt.setString(5, Sanss_salon_name);
                    pstmt.setString(6, bilitAddFilmNameComboList.getValue());


                    pstmt.setInt(7, Integer.parseInt(bilitAddNumberOfChair.getText()));
                    updateAvalableCHair(bilitAddFilmNameComboList.getValue(), Sanss_time, String.valueOf(bilitAddFilmDatePicker.getValue()), Sanss_salon_name, Integer.parseInt(bilitAddNumberOfChair.getText()));

                    price = getSalonPrice(Sanss_salon_name) * Integer.parseInt(bilitAddNumberOfChair.getText());
                    pstmt.setInt(8, price);


                    pstmt.executeUpdate();
                } catch (SQLException throwable) {
                    throwable.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
                bilitList.add(new Bilit(bilitAddName.getText(), Sanss_salon_name, bilitAddFilmNameComboList.getValue(), Sanss_time, String.valueOf(bilitAddFilmDatePicker.getValue()), id, Integer.parseInt(bilitAddNumberOfChair.getText()), price));
                //initialize(location,resources);


                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("پیام");
                alert.setHeaderText("اطلاعات بیلیت");
                String temp = "بیلیت ثبت شد";
                temp += "\n" + "نام:" + bilitAddName.getText();
                temp += "\n" + "فیلم:" + bilitAddFilmNameComboList.getValue();
                temp += "\n" + "سالن:" + Sanss_salon_name;
                temp += "\n" + "تاریخ:" + String.valueOf(bilitAddFilmDatePicker.getValue());
                temp += "\n" + "زمان:" + Sanss_time;
                temp += "\n" + "تعداد:" + bilitAddNumberOfChair.getText();
                temp += "\n" + "شناسه بیلیت:" + id;
                temp += "\n" + "مجموع حساب:" + price;

                temp += "\n\n" + "!!اگر بیلیت تکراری وارد کرده باشید در اجرای بعدی برنامه از جدول نمایش حذف خواهد شد";
                temp += "\n\n" + "!!تغییرات در ظرفیت باقی مانده از سانس اعمال شده است و در اجرای بعدی برنامه در جدول نیز اعمل میشود";

                alert.setContentText(temp);
                alert.getDialogPane().getScene().setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.showAndWait();
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("پیام");
                alert.setHeaderText("اطلاعات سانس");
                alert.setContentText("در سانسس مورد نظر شما به اندازه کافی صندلی خالی موجود نمیباشد");
                alert.getDialogPane().getScene().setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.showAndWait();
            }
            bilitAddNumberOfChair.setText("");
            bilitAddName.setText("");
            bilitAddSalonNameComboList.setValue(null);
            bilitAddFilmNameComboList.setValue(null);
            bilitAddFilmDatePicker.setValue(null);

        });
        bilitDeleteByIdButton.setOnAction(event -> {
            String id = bilitDeleteById.getText();
            deleteBilit(id);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("پیام");
            alert.setHeaderText("بلیت پاک شد");
            alert.setContentText("بلیتی با id : ");
            alert.setContentText(bilitDeleteById.getText() + "از پایگاه داده پاک شد");
            alert.setContentText("\n");
            alert.setContentText("!!در اجرای بعدی برنامه تغییرات در جدول برنامه اعمال میشوند");
            alert.getDialogPane().getScene().setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.showAndWait();
            bilitDeleteById.setText("");
        });

        sanssDeleteByIdButton.setOnAction(event -> {
            String id = sanssDeleteById.getText();
            sanssDelete(id);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("پیام");
            alert.setHeaderText("سانس پاک شد");
            String temp = "سانس با id : ";
            temp += id;
            temp += "\n از پایگاه داده حذف شذ";
            temp += "\n";
            temp += "!!بلیت های مرتبط با این سانس نیز حذف شده است";
            temp += "\n" + "!!در اجرای بعدی برنامه تغییرات در جدول برنامه اعمال میشوند";
            alert.setContentText(temp);
            alert.getDialogPane().getScene().setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.showAndWait();
            sanssDeleteById.setText("");

        });


        reportGetAllSellOfAFilmButton.setOnAction(event -> {
            String film = reportNameOfFilmThatHaveSanss.getValue();

            Connection connection;
            ResultSet rs;
            int sum = 0;
            try {
                connection = dbHandler.getConnection();
                PreparedStatement statement = connection.prepareStatement("SELECT price FROM bilit WHERE film_name = '" + film + "'");
                rs = statement.executeQuery();
                while (rs.next()) {
                    sum += rs.getInt("price");
                }

            } catch (Exception exception) {
                System.out.println(exception);
            }
            reportGetAllSellOfAFilmLable.setText(String.valueOf(sum));
            System.out.println(1);
        });

        reportGetAllSellOfASalonButton.setOnAction(event -> {
            String salon = reportNameOfSalonThatHaveSanss.getValue();

            Connection connection;
            ResultSet rs;
            int sum = 0;
            try {
                connection = dbHandler.getConnection();
                PreparedStatement statement = connection.prepareStatement("SELECT price FROM bilit WHERE salon_name = '" + salon + "'");
                rs = statement.executeQuery();
                while (rs.next()) {
                    sum += rs.getInt("price");
                }

            } catch (Exception exception) {
                System.out.println(exception);
            }
            reportGetAllSellOfASalonLable.setText(String.valueOf(sum));
            System.out.println(2);
        });

        reportGetAllSellOfAFilmButtonOnDate.setOnAction(event -> {
            String film = reportNameOfFilmThatHaveSanssOnDate.getValue();
            String date = String.valueOf(reportOnThisDate.getValue());

            Connection connection;
            ResultSet rs;
            int sum = 0;
            try {
                connection = dbHandler.getConnection();
                PreparedStatement statement = connection.prepareStatement("SELECT price FROM bilit WHERE film_name = '" + film + "' AND date ='" + date + "'");
                rs = statement.executeQuery();
                while (rs.next()) {
                    sum += rs.getInt("price");
                }

            } catch (Exception exception) {
                System.out.println(exception);
            }
            reportGetAllSellOfAFilmLableOnDate.setText(String.valueOf(sum));
            System.out.println(3);
        });

        reportGetAllSellOfAFSalonButtonOnDate.setOnAction(event -> {
            String salon = reportNameOfSalonThatHaveSanssOnDate.getValue();
            String date = String.valueOf(reportOnThisDate.getValue());
            Connection connection;
            ResultSet rs;
            int sum = 0;
            try {
                connection = dbHandler.getConnection();
                PreparedStatement statement = connection.prepareStatement("SELECT price FROM bilit WHERE salon_name = '" + salon + "'AND date ='" + date + "'");
                rs = statement.executeQuery();
                while (rs.next()) {
                    sum += rs.getInt("price");
                }

            } catch (Exception exception) {
                System.out.println(exception);
            }
            reportGetAllSellOfASalonLableOnDate.setText(String.valueOf(sum));
            System.out.println(4);
        });

        reportGetMostSellFilmButton.setOnAction(event -> {
            Connection connection;
            ResultSet rs;
            int sum = 0;
            String want = null;
            try {
                connection = dbHandler.getConnection();
                PreparedStatement statement = connection.prepareStatement("SELECT DISTINCT film_name FROM bilit");
                rs = statement.executeQuery();
                while (rs.next()) {
                    int x = getMountOfSell("film_name", rs.getString("film_name"));
                    if (x > sum) {
                        sum = x;
                        want = rs.getString("film_name");
                    }
                }

            } catch (Exception exception) {
                System.out.println(exception);
            }
            reportGetMostSellFilmLable.setText(want + " : " + sum);
        });
        reportGetMostSellSalonButton.setOnAction(event -> {
            Connection connection;
            ResultSet rs;
            int sum = 0;
            String want = null;
            try {
                connection = dbHandler.getConnection();
                PreparedStatement statement = connection.prepareStatement("SELECT DISTINCT salon_name FROM bilit");
                rs = statement.executeQuery();
                while (rs.next()) {
                    int x = getMountOfSell("salon_name", rs.getString("salon_name"));
                    if (x > sum) {
                        sum = x;
                        want = rs.getString("salon_name");
                    }
                }

            } catch (Exception exception) {
                System.out.println(exception);
            }
            reportGetMostSellFilmLable.setText(want + " : " + sum);
        });

        playListButton.setOnAction(event -> {
            System.out.println(0);
            String date = String.valueOf(playlistInThisDate.getValue());
            String t1 = "";
            String t2 = "";
            String t3 = "";
            String t4 = "";

            Connection connection;
            ResultSet rs;
            try {
                System.out.println(1);
                connection = dbHandler.getConnection();
                PreparedStatement statement = connection.prepareStatement("SELECT * FROM sanss WHERE sanss_date ='" + date + "'");
                rs = statement.executeQuery();
                while (rs.next()) {
                    System.out.println(2);
                    String Msanss = rs.getString("sanss_time");


                    if (Msanss.equals("(9-11)")) {
                        System.out.println(10);
                        t1 += rs.getString("salon_name") + " : " + rs.getString("film_name") + "\n\n";
                    } else if (Msanss.equals("(11-13)")) {
                        System.out.println(10);
                        t2 += rs.getString("salon_name") + " : " + rs.getString("film_name") + "\n\n";
                    } else if (Msanss.equals("(15-17)")) {
                        System.out.println(10);
                        t3 += rs.getString("salon_name") + " : " + rs.getString("film_name") + "\n\n";
                    } else if (Msanss.equals("(17-19)")) {
                        System.out.println(10);
                        t4 += rs.getString("salon_name") + " : " + rs.getString("film_name") + "\n\n";
                    }


                    //t1 += rs.getString("salon_name")+" : "+rs.getString("film_name")+"\n\n";

                }

            } catch (Exception exception) {
                System.out.println(exception);
            }
            if (t1.equals("")) {
                t1 = "در این زمان و تاریخ" + "\n" + "در هیچ کدام از سالن ها" + "\n" + "سانسی تعریف نشده";
            }
            if (t2.equals("")) {
                t2 = "در این زمان و تاریخ" + "\n" + "در هیچ کدام از سالن ها" + "\n" + "سانسی تعریف نشده";
            }
            if (t3.equals("")) {
                t3 = "در این زمان و تاریخ" + "\n" + "در هیچ کدام از سالن ها" + "\n" + "سانسی تعریف نشده";
            }
            if (t4.equals("")) {
                t4 = "در این زمان و تاریخ" + "\n" + "در هیچ کدام از سالن ها" + "\n" + "سانسی تعریف نشده";
            }
            sanss1.setText(t1);
            sanss2.setText(t2);
            sanss3.setText(t3);
            sanss4.setText(t4);
            System.out.println(3);
        });

        filmDeleteByIdButton.setOnAction(event -> {
            String id = filmDeleteById.getText();
            FilmDelete(id);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("پیام");
            alert.setHeaderText("فیلم پاک شد");
            String temp = "فیلم با id : ";
            temp += id;
            temp += "\n از پایگاه داده حذف شذ";
            temp += "\n";
            temp += "!!بلیت هاو سانس های  مرتبط با این فیلم نیز حذف شده است";
            temp += "\n" + "!!در اجرای بعدی برنامه تغییرات در جدول برنامه اعمال میشوند";
            alert.setContentText(temp);
            alert.getDialogPane().getScene().setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.showAndWait();
            filmDeleteById.setText("");

        });
        salonDeleteButton.setOnAction(event -> {
            String salon = salonDeleteName.getText();
            SalonDelete(salon);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("پیام");
            alert.setHeaderText(" سالن پاک شد");
            String temp = "سالن  : ";
            temp += salon;
            temp += "\n از پایگاه داده حذف شد";
            temp += "\n";
            temp += "!!بلیت هاو سانس های  مرتبط با این سالن نیز حذف شده است";
            temp += "\n" + "!!در اجرای بعدی برنامه تغییرات در جدول برنامه اعمال میشوند";
            alert.setContentText(temp);
            alert.getDialogPane().getScene().setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.showAndWait();
            filmDeleteById.setText("");
        });
    }

    private int getMountOfSell(String x, String film) {
        Connection connection;
        ResultSet rs;
        int sum = 0;
        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT price FROM bilit WHERE " + x + " = '" + film + "'");
            rs = statement.executeQuery();
            while (rs.next()) {
                sum += rs.getInt("price");
            }

        } catch (Exception exception) {
            System.out.println(exception);
        }
        return sum;
    }

    private void sanssDelete(String id) {
        String sql1 = "DELETE FROM sanss WHERE sanss_uniqe_id = '" + id + "'";
        String sql2 = "DELETE FROM bilit WHERE bilit_id LIKE '%" + id + "%'";
        try {
            Connection conn = dbHandler.getConnection();
            PreparedStatement pstmt1 = conn.prepareStatement(sql1);
            // execute the delete statement
            pstmt1.executeUpdate();

            PreparedStatement pstmt2 = conn.prepareStatement(sql2);
            // execute the delete statement
            pstmt2.executeUpdate();


        } catch (SQLException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private String checkExistance(String salon, String time, String date) {
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT film_name FROM sanss WHERE salon_name = '" + salon + "' AND sanss_time ='" + time + "' AND sanss_date='" + date + "'");
            rs = statement.executeQuery();
            System.out.println(10);
            return rs.getString("film_name");

        } catch (Exception e) {
            System.out.println(e);
        }
        return "";
    }

    private String getFilmNameById(String id) {
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT film_name FROM films WHERE pub_film_id = '" + id + "'");
            rs = statement.executeQuery();

            return rs.getString("film_name");
        } catch (Exception e) {
            System.out.println(e);
        }
        return "";
    }

    private void FilmDelete(String id) {
        String film = getFilmNameById(id);
        String sql1 = "DELETE FROM films WHERE film_name = '" + film + "'";
        String sql2 = "DELETE FROM sanss WHERE film_name = '" + film + "'";
        String sql3 = "DELETE FROM bilit WHERE film_name = '" + film + "'";

        try {
            Connection conn = dbHandler.getConnection();
            PreparedStatement pstmt1 = conn.prepareStatement(sql1);
            // execute the delete statement
            pstmt1.executeUpdate();

            PreparedStatement pstmt2 = conn.prepareStatement(sql2);
            // execute the delete statement
            pstmt2.executeUpdate();
            PreparedStatement pstmt3 = conn.prepareStatement(sql3);
            // execute the delete statement
            pstmt3.executeUpdate();


        } catch (SQLException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private void SalonDelete(String salon) {

        String sql1 = "DELETE FROM salon WHERE salon_name = '" + salon + "'";
        String sql2 = "DELETE FROM sanss WHERE salon_name = '" + salon + "'";
        String sql3 = "DELETE FROM bilit WHERE salon_name = '" + salon + "'";

        try {
            Connection conn = dbHandler.getConnection();
            PreparedStatement pstmt1 = conn.prepareStatement(sql1);
            // execute the delete statement
            pstmt1.executeUpdate();

            PreparedStatement pstmt2 = conn.prepareStatement(sql2);
            // execute the delete statement
            pstmt2.executeUpdate();
            PreparedStatement pstmt3 = conn.prepareStatement(sql3);
            // execute the delete statement
            pstmt3.executeUpdate();


        } catch (SQLException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private void deleteBilit(String id) {
        String sql = "DELETE FROM bilit WHERE bilit_id = '" + id + "'";

        try {
            Connection conn = dbHandler.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // execute the delete statement
            pstmt.executeUpdate();

        } catch (SQLException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private String getFilmId(String film_name) {
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT pub_film_id FROM films WHERE film_name = '" + film_name + "'");
            rs = statement.executeQuery();

            return rs.getString("pub_film_id");
        } catch (Exception e) {
            System.out.println(e);
        }
        return "";
    }

    private int findZarfiat(String Salon_name) {
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT salon_zarfiat FROM salon WHERE salon_name = '" + Salon_name + "'");
            rs = statement.executeQuery();

            return rs.getInt("salon_zarfiat");
        } catch (Exception e) {
            System.out.println(e);
        }
        return -1;
    }

    private boolean haveChair(String film, String time, String date, String salon, int numberOfChair) {
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT zarfiat_mojod FROM sanss WHERE film_name = '" + film + "' AND sanss_date ='" + date + "' AND sanss_time ='" + time + "' AND salon_name ='" + salon + "'");
            rs = statement.executeQuery();
            System.out.println("hi2");
            if (rs.getInt("zarfiat_mojod") - numberOfChair >= 0) {
                return true;

            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    private void updateAvalableCHair(String film, String time, String date, String salon, int numberOfChair) {
        Connection connection;
        ResultSet rs;
        String sql = "UPDATE sanss SET zarfiat_mojod = zarfiat_mojod - " + String.valueOf(numberOfChair)
                + " WHERE film_name = '" + film + "' AND sanss_date ='" + date + "' AND sanss_time ='" + time + "' AND salon_name ='" + salon + "'";

        try {
            connection = dbHandler.getConnection();
            PreparedStatement pstmt = connection.prepareStatement(sql);

            pstmt.executeUpdate();


            System.out.println("hi");


        } catch (Exception e) {
            System.out.println(e);
        }

    }

    private int getSalonPrice(String salon) {
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT salon_price FROM salon WHERE salon_name = '" + salon + "'");
            rs = statement.executeQuery();
            System.out.println("hi");
            return rs.getInt("salon_price");

        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    private String getSanssId(String film, String time, String date, String salon) {
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT sanss_uniqe_id FROM sanss WHERE film_name = '" + film + "' AND salon_name ='" + salon + "' AND sanss_time ='" + time + "' AND sanss_date='" + date + "'");
            rs = statement.executeQuery();

            return rs.getString("sanss_uniqe_id");

        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
    //fill tables

    private void fillTables() {
        fillTableSalon();
        fillTableFilm();
        fillTableSanss();
        fillTableBilit();
        System.out.println("tables filled");
        sanssFilmNameComboList();
        sanssSalonNameComboList();
        sanssTimeComboList();
        bilitFilmComboLIst();
        filReportSalonNameComboList();
    }

    private void fillTableSalon() {
        //salon
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM salon");
            rs = statement.executeQuery();
            salonList = FXCollections.observableArrayList();
            while (rs.next()) {
                String salon_name = rs.getString("salon_name");
                int salon_price = rs.getInt("salon_price");
                int salon_zarfiat = rs.getInt("salon_zarfiat");
                salonList.add(new Salon(salon_name, salon_price, salon_zarfiat));
                System.out.println(salon_name + " " + salon_price + " " + salon_zarfiat);
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        salonTableCSalonName.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Salon) cellData.getValue()).getSalonName()));
        });

        salonTableCPricePerChair.setCellValueFactory(cellData -> {
            return (new SimpleIntegerProperty(((Salon) cellData.getValue()).getSalonPrice())).asObject();
        });
        salonTableCZarfiat.setCellValueFactory(cellData -> {
            return (new SimpleIntegerProperty(((Salon) cellData.getValue()).getSalonZarfiat())).asObject();
        });
        salonTable.setItems(salonList);
        salonTable.getColumns().addAll(salonTableCSalonName, salonTableCPricePerChair, salonTableCZarfiat);
        salonTable.refresh();
    }

    private void fillTableFilm() {
        //salon
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM films");
            rs = statement.executeQuery();
            filmList = FXCollections.observableArrayList();
            while (rs.next()) {
                String film_name = rs.getString("film_name");
                String film_pub_id = rs.getString("pub_film_id");
                filmList.add(new Film(film_name, film_pub_id));
                //System.out.println(salon_name + " " + salon_price + " " + salon_zarfiat );
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        filmTableCFilmName.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Film) cellData.getValue()).getFilmName()));
        });
        filmTableCFilmId.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Film) cellData.getValue()).getFilmId()));
        });
        filmTable.setItems(filmList);
        filmTable.getColumns().addAll(filmTableCFilmName, filmTableCFilmId);
        filmTable.refresh();
    }

    private void fillTableSanss() {
        //sanss
        Connection connection;
        ResultSet rs;

        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM sanss");
            rs = statement.executeQuery();
            sanssList = FXCollections.observableArrayList();
            while (rs.next()) {
                String salon_name = rs.getString("salon_name");
                String film_name = rs.getString("film_name");
                String sanss_time = rs.getString("sanss_time");
                String sanss_date = rs.getString("sanss_date");
                String sanss_uniqe_id = rs.getString("sanss_uniqe_id");
                int availableZarfiat = rs.getInt("zarfiat_mojod");
                sanssList.add(new Sanss(salon_name, film_name, sanss_time, sanss_date, sanss_uniqe_id, availableZarfiat));
                //System.out.println(salon_name );
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        sanssTableCSalonName.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Sanss) cellData.getValue()).getSalonName()));
        });
        sanssTableCFilmName.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Sanss) cellData.getValue()).getFilmName()));
        });
        sanssTableCDate.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Sanss) cellData.getValue()).getSanssDate()));
        });
        sanssTableCTime.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Sanss) cellData.getValue()).getSanssTime()));
        });
        sanssTableCSanssId.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Sanss) cellData.getValue()).getSanssId()));
        });
        sanssTableCZarfiat.setCellValueFactory(cellData -> {
            return (new SimpleIntegerProperty(((Sanss) cellData.getValue()).getAvailableZarfiat())).asObject();
        });
        sanssTable.setItems(sanssList);
        sanssTable.getColumns().addAll(sanssTableCFilmName, sanssTableCSalonName, sanssTableCTime, sanssTableCDate, sanssTableCZarfiat, sanssTableCSanssId);
        sanssTable.refresh();
    }

    private void fillTableBilit() {
        //bilit
        Connection connection;
        ResultSet rs;
        bilitList = null;
        try {
            connection = dbHandler.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM bilit");
            rs = statement.executeQuery();
            bilitList = FXCollections.observableArrayList();
            while (rs.next()) {
                String personName = rs.getString("name");
                String bilitId = rs.getString("bilit_id");
                String sanss_time = rs.getString("time");
                String sanss_date = rs.getString("date");
                String salon_name = rs.getString("salon_name");
                String film_name = rs.getString("film_name");
                int numberOfChair = rs.getInt("number_of_ticket");
                int price = rs.getInt("price");

                bilitList.add(new Bilit(personName, salon_name, film_name, sanss_time, sanss_date, bilitId, numberOfChair, price));
                //System.out.println(salon_name );
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        bilitTableCPersonName.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Bilit) cellData.getValue()).getPersonName()));
        });
        bilitTableCBilitId.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Bilit) cellData.getValue()).getBilitId()));
        });
        bilitTableCSalonName.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Bilit) cellData.getValue()).getSalonName()));
        });
        bilitTableCFilmName.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Bilit) cellData.getValue()).getFilmName()));
        });
        bilitTableCDate.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Bilit) cellData.getValue()).getSanssDate()));
        });
        bilitTableCTime.setCellValueFactory(cellData -> {
            return (new SimpleStringProperty(((Bilit) cellData.getValue()).getSanssTime()));
        });
        bilitTableCNumberOfChair.setCellValueFactory(cellData -> {
            return (new SimpleIntegerProperty(((Bilit) cellData.getValue()).getNumberOfChair())).asObject();
        });
        bilitTableCPrice.setCellValueFactory(cellData -> {
            return (new SimpleIntegerProperty(((Bilit) cellData.getValue()).getPrice())).asObject();
        });
        bilitTable.setItems(bilitList);
        bilitTable.getColumns().addAll(bilitTableCPersonName, bilitTableCBilitId, bilitTableCTime, bilitTableCDate, bilitTableCSalonName, bilitTableCFilmName, bilitTableCNumberOfChair, bilitTableCPrice);
        bilitTable.refresh();
    }

    public void sanssFilmNameComboList() {
        Connection conn = null;
        try {
            sanssFilmName = FXCollections.observableArrayList();
            String consulta = "select film_name from films";
            conn = dbHandler.getConnection();
            PreparedStatement ps = conn.prepareStatement(consulta);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                sanssFilmName.add(rs.getString("film_name"));
            }

            sanssAddFilmNameComboList.setItems(sanssFilmName);
            //reportNameOfSalonThatHaveSanss.setItems(sanssFilmName);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    private void filReportSalonNameComboList() {
        Connection conn = null;
        try {
            sanssFilmName = FXCollections.observableArrayList();
            String consulta = "select DISTINCT salon_name from sanss";
            conn = dbHandler.getConnection();
            PreparedStatement ps = conn.prepareStatement(consulta);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                sanssFilmName.add(rs.getString("salon_name"));
            }

            //sanssAddFilmNameComboList.setItems(sanssFilmName);
            reportNameOfSalonThatHaveSanss.setItems(sanssFilmName);
            reportNameOfSalonThatHaveSanssOnDate.setItems(sanssFilmName);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void sanssSalonNameComboList() {
        Connection conn = null;
        try {
            sanssSalonName = FXCollections.observableArrayList();
            String consulta = "select salon_name from salon";
            conn = dbHandler.getConnection();
            PreparedStatement ps = conn.prepareStatement(consulta);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                sanssSalonName.add(rs.getString("salon_name"));
            }

            sanssAddSalonNameComboList.setItems(sanssSalonName);

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    private void bilitFilmComboLIst() {
        Connection conn = null;
        try {
            bilitFilmName = FXCollections.observableArrayList();
            String consulta = "select DISTINCT film_name from sanss";
            conn = dbHandler.getConnection();
            PreparedStatement ps = conn.prepareStatement(consulta);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                if (!bilitFilmName.contains(rs.getString("film_name"))) ;
                {
                    bilitFilmName.add(rs.getString("film_name"));
                }
            }

            bilitAddFilmNameComboList.setItems(bilitFilmName);
            reportNameOfFilmThatHaveSanss.setItems(bilitFilmName);
            reportNameOfFilmThatHaveSanssOnDate.setItems(bilitFilmName);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    private void sanssTimeComboList() {
        sanssTime = FXCollections.observableArrayList();
        sanssTime.add("(9-11)");
        sanssTime.add("(11-13)");
        sanssTime.add("(15-17)");
        sanssTime.add("(17-19)");
        sanssAddTimeComboList.setItems(sanssTime);
        //bilitAddTimeComboList.setItems(sanssTime);
    }

    private void dateFormatConverter() {
        sanssAddDatePicker.setConverter(new StringConverter<LocalDate>() {
            String pattern = "yyyy-MM-dd";
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

            {
                sanssAddDatePicker.setPromptText(pattern.toLowerCase());
            }

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });
        playlistInThisDate.setConverter(new StringConverter<LocalDate>() {
            String pattern = "yyyy-MM-dd";
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

            {
                playlistInThisDate.setPromptText(pattern.toLowerCase());
            }

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });


        bilitAddFilmDatePicker.setConverter(new StringConverter<LocalDate>() {
            String pattern = "yyyy-MM-dd";
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

            {
                bilitAddFilmDatePicker.setPromptText(pattern.toLowerCase());
            }

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });
        reportOnThisDate.setConverter(new StringConverter<LocalDate>() {
            String pattern = "yyyy-MM-dd";
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

            {
                reportOnThisDate.setPromptText(pattern.toLowerCase());
            }

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });
    }
}
