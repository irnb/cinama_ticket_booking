package cinemaHamid.model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Bilit {
    private SimpleStringProperty personName , salonName , filmName , sanssTime , sanssDate , bilitId;
    private SimpleIntegerProperty numberOfChair , price;

    public Bilit(String personName, String salonName, String filmName, String sanssTime, String sanssDate, String bilitId, Integer numberOfChair, Integer price) {
        this.personName = new SimpleStringProperty(personName);
        this.salonName = new SimpleStringProperty(salonName);
        this.filmName = new SimpleStringProperty(filmName);
        this.sanssTime = new SimpleStringProperty(sanssTime);
        this.sanssDate = new SimpleStringProperty(sanssDate);
        this.bilitId = new SimpleStringProperty(bilitId);
        this.numberOfChair = new SimpleIntegerProperty(numberOfChair);
        this.price = new SimpleIntegerProperty(price);
    }

    public String getPersonName() {
        return personName.get();
    }

    public SimpleStringProperty personNameProperty() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName.set(personName);
    }

    public String getSalonName() {
        return salonName.get();
    }

    public SimpleStringProperty salonNameProperty() {
        return salonName;
    }

    public void setSalonName(String salonName) {
        this.salonName.set(salonName);
    }

    public String getFilmName() {
        return filmName.get();
    }

    public SimpleStringProperty filmNameProperty() {
        return filmName;
    }

    public void setFilmName(String filmName) {
        this.filmName.set(filmName);
    }

    public String getSanssTime() {
        return sanssTime.get();
    }

    public SimpleStringProperty sanssTimeProperty() {
        return sanssTime;
    }

    public void setSanssTime(String sanssTime) {
        this.sanssTime.set(sanssTime);
    }

    public String getSanssDate() {
        return sanssDate.get();
    }

    public SimpleStringProperty sanssDateProperty() {
        return sanssDate;
    }

    public void setSanssDate(String sanssDate) {
        this.sanssDate.set(sanssDate);
    }

    public String getBilitId() {
        return bilitId.get();
    }

    public SimpleStringProperty bilitIdProperty() {
        return bilitId;
    }

    public void setBilitId(String bilitId) {
        this.bilitId.set(bilitId);
    }

    public int getNumberOfChair() {
        return numberOfChair.get();
    }

    public SimpleIntegerProperty numberOfChairProperty() {
        return numberOfChair;
    }

    public void setNumberOfChair(int numberOfChair) {
        this.numberOfChair.set(numberOfChair);
    }

    public int getPrice() {
        return price.get();
    }

    public SimpleIntegerProperty priceProperty() {
        return price;
    }

    public void setPrice(int price) {
        this.price.set(price);
    }
}
