package cinemaHamid.model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

import java.util.Random;

public class Film {
    private SimpleStringProperty filmName,filmId;
    public static int countForMe(){
        return (int)(Math.random() * ((100 - 3) + 1)) + 3;
    }
    public Film(String filmName, String filmId) {
        this.filmName = new SimpleStringProperty(filmName);
        this.filmId = new SimpleStringProperty(filmId);
    }

    public String getFilmName() {
        return filmName.get();
    }

    public SimpleStringProperty filmNameProperty() {
        return filmName;
    }

    public void setFilmName(String filmName) {
        this.filmName.set(filmName);
    }

    public String getFilmId() {
        return filmId.get();
    }

    public SimpleStringProperty filmIdProperty() {
        return filmId;
    }

    public void setFilmId(String filmId) {
        this.filmId.set(filmId);
    }
}
