package cinemaHamid.model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

import java.text.SimpleDateFormat;

public class Salon {
    private SimpleStringProperty salonName;
    private SimpleIntegerProperty salonPrice, salonZarfiat;

    public Salon(String salonName, Integer salonPrice, Integer salonZarfiat) {
        this.salonName = new SimpleStringProperty(salonName);
        this.salonPrice = new SimpleIntegerProperty(salonPrice);
        this.salonZarfiat = new SimpleIntegerProperty(salonZarfiat);
    }

    public String getSalonName() {
        return salonName.get();
    }

    public SimpleStringProperty salonNameProperty() {
        return salonName;
    }

    public void setSalonName(String salonName) {
        this.salonName.set(salonName);
    }

    public int getSalonPrice() {
        return salonPrice.get();
    }

    public SimpleIntegerProperty salonPriceProperty() {
        return salonPrice;
    }

    public void setSalonPrice(int salonPrice) {
        this.salonPrice.set(salonPrice);
    }

    public int getSalonZarfiat() {
        return salonZarfiat.get();
    }

    public SimpleIntegerProperty salonZarfiatProperty() {
        return salonZarfiat;
    }

    public void setSalonZarfiat(int salonZarfiat) {
        this.salonZarfiat.set(salonZarfiat);
    }
}
