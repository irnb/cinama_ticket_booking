package cinemaHamid.model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Sanss {
    private SimpleStringProperty salonName , filmName , sanssTime , sanssDate , sanssId;
    private SimpleIntegerProperty availableZarfiat;

    public Sanss(String salonName, String filmName, String sanssTime, String sanssDate, String sanssId, Integer availableZarfiat) {
        this.salonName = new SimpleStringProperty(salonName);
        this.filmName = new SimpleStringProperty(filmName);
        this.sanssTime = new SimpleStringProperty(sanssTime);
        this.sanssDate = new SimpleStringProperty(sanssDate);
        this.sanssId = new SimpleStringProperty(sanssId);
        this.availableZarfiat = new SimpleIntegerProperty(availableZarfiat);
    }

    public String getSalonName() {
        return salonName.get();
    }

    public SimpleStringProperty salonNameProperty() {
        return salonName;
    }

    public void setSalonName(String salonName) {
        this.salonName.set(salonName);
    }

    public String getFilmName() {
        return filmName.get();
    }

    public SimpleStringProperty filmNameProperty() {
        return filmName;
    }

    public void setFilmName(String filmName) {
        this.filmName.set(filmName);
    }

    public String getSanssTime() {
        return sanssTime.get();
    }

    public SimpleStringProperty sanssTimeProperty() {
        return sanssTime;
    }

    public void setSanssTime(String sanssTime) {
        this.sanssTime.set(sanssTime);
    }

    public String getSanssDate() {
        return sanssDate.get();
    }

    public SimpleStringProperty sanssDateProperty() {
        return sanssDate;
    }

    public void setSanssDate(String sanssDate) {
        this.sanssDate.set(sanssDate);
    }

    public String getSanssId() {
        return sanssId.get();
    }

    public SimpleStringProperty sanssIdProperty() {
        return sanssId;
    }

    public void setSanssId(String sanssId) {
        this.sanssId.set(sanssId);
    }

    public int getAvailableZarfiat() {
        return availableZarfiat.get();
    }

    public SimpleIntegerProperty availableZarfiatProperty() {
        return availableZarfiat;
    }

    public void setAvailableZarfiat(int availableZarfiat) {
        this.availableZarfiat.set(availableZarfiat);
    }
}
