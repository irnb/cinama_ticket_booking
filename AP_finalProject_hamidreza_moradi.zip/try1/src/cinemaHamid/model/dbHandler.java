package cinemaHamid.model;
import java.sql.*;

public class dbHandler {
    static Connection connection = null;
    static Statement stmt = null;


    public static Connection connect(){

        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:src/cinemaHamid/db/cinemaHamid.db");
            System.out.println("Opened database successfully");
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
        }
        return  connection ;
    }
    public static Connection getConnection() throws SQLException, ClassNotFoundException{
        if(connection !=null && !connection.isClosed())
            return connection;
        connect();
        return connection;

    }

    public  static void insertSalon(){

    }
    public  static void deleteSalon(){

    }
    public  static void modifySalon(){

    }
    public  static void readSalon(){

    }



    public  static void insertFilm(){

    }
    public  static void deleteFilm(){

    }
    public  static void readFilm(){

    }



    public  static void insertSans(){

    }
    public  static void deleteSans(){

    }
    public  static void readSans(){

    }



    public  static void insertBilit(){

    }
    public  static void deleteBilit(){

    }
    public  static void readBilit(){

    }

}
